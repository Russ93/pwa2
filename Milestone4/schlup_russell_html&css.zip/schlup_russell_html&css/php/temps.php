login: [{"<div id="jqlogin">
			<header>
				<h1>login</h1>
				<button>remove</button>
			</header>
			<label>username:</label><input/>
			<label>password:</label><input/>
			<button class="sign">log in</button>
		</div>"}]